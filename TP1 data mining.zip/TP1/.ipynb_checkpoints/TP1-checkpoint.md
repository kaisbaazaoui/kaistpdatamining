# TP1 : Traitement des données 



## Le deadline sera fixé pour le 12 octobres 2020

## En attendant vous pouvez commencez la [certification 1][cdi]



[cdi]: https://learn.datacamp.com/courses/cleaning-data-in-python





